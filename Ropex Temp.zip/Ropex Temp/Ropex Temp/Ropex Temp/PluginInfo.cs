﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.ropextemp.gorillatag.menutemplate.lmao";
        public const string Name = "Ropex Temp";
        public const string Description = "Created by @﷽\n with gyats <3";
        public const string Version = "1.0"; //Update this for every release ITS IMPORTANT
    }
}
