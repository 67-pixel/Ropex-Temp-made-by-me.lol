# Mod Menu Template  

![Mod Menu Banner](https://media.discordapp.net/attachments/1347297385553989732/1350229913306660969/image.png?ex=67d6a3d9&is=67d55259&hm=60edf2472ea54e82987e8e3a3c772e185704861490153cb72c1c392602ec1201&=&format=webp&quality=lossless&width=452&height=544)  

## 🚀 About  
It’s inspired by **scintilla**, and I hope you enjoy it.  

## 💡 Suggestions  
If you’d like me to create more templates, let me know!  
Join our **Discord server** and drop your suggestions:  
👉 [Join Here](https://discord.gg/KXABTbrQx2)  

## 📜 Disclaimer  
This is for **educational purposes only**. I am not responsible for how this is used.  

## ❤️ Credits  
Credits to **iidk** for the main template it made it easier to create menus with it.  
*(Also please make me an actual mod creator in your server)*  
